﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Threading;
using System.IO;

public class ChatBot
{
    private static readonly string VoiceGreetingPath = "PROG_ASS_VOICE.wav";
    private const string ExitCommand = "bye";

    // Memory
    private static Dictionary<string, string> userMemory = new Dictionary<string, string>();
    private static string currentTopic = null;
    private static List<string> conversationHistory = new List<string>();

    // Greetings and Farewells
    private static readonly List<string> greetings = new List<string> {
        "Hello there!", "Hi!", "Greetings!", "Hey!", "Welcome back!"
    };
    private static readonly List<string> farewells = new List<string> {
        "Goodbye!", "Bye for now!", "Have a good one!", "Take care!", "See you later!"
    };
    private static readonly List<string> acknowledgement = new List<string> {
        "Got it.", "Understood.", "Okay.", "Right.", "I see."
    };
    private static readonly List<string> positiveAffirmations = new List<string> {
        "That's a great question!", "Interesting point!", "Good to know!", "Excellent!", "I agree."
    };
    private static readonly List<string> followUpQuestions = new List<string> {
        "What else would you like to know about that?", "Is there anything specific you're curious about?",
        "Do you have any other questions related to this?", "How else can I assist you with this topic?"
    };
    private static readonly List<string> confusionResponses = new List<string> {
        "Hmm, that's an interesting way to put it. Could you clarify?",
        "I'm not entirely sure I follow. Could you say more?",
        "Could you perhaps rephrase your question?",
        "What exactly are you wondering about?"
    };

    // Cybersecurity Knowledge Base
    private static readonly Dictionary<string, List<string>> randomResponses = new Dictionary<string, List<string>> {
        { "phishing", new List<string> {
            "Phishing can be sneaky! Always double-check the sender's email address.",
            "Think before you click! Malicious links in emails can lead to trouble.",
            "Never share passwords via email. Scammers impersonate trusted contacts.",
            "Grammar and spelling errors in emails can be a red flag.",
            "Be cautious with attachments from unknown sources."
        }},
        { "password", new List<string> {
            "Use a strong password: mix uppercase, lowercase, numbers, and symbols.",
            "Don't reuse passwords across accounts. Consider a password manager!",
            "Enable two-factor authentication wherever possible.",
            "Avoid using personal information like birthdays in passwords.",
            "Change your passwords regularly, especially after a breach."
        }},
        { "scam", new List<string> {
            "Be skeptical of offers that sound too good to be true.",
            "Never share sensitive data with unverified sources.",
            "Watch out for messages that pressure immediate action.",
            "Legitimate companies don’t ask for sensitive info via text or email.",
            "Stay informed about new types of scams."
        }},
        { "privacy", new List<string> {
            "Review your privacy settings on all your accounts.",
            "Limit personal info shared on social media.",
            "Use VPNs on public Wi-Fi to protect your data.",
            "Think twice before granting app permissions.",
            "Understand how websites track your activity."
        }}
    };

    // Emotional Awareness
    private static readonly Dictionary<string, string> sentimentResponses = new Dictionary<string, string> {
        { "worried", "It's completely understandable to feel that way. Let's explore some ways to ease your concerns." },
        { "concerned", "I hear you. Cybersecurity can be overwhelming sometimes. Let's break it down." },
        { "frustrated", "That sounds frustrating. Let’s work through it together." },
        { "curious", "That's a fantastic attitude! Curiosity is key to learning." },
        { "unsure", "It's perfectly normal to feel unsure. I'm here to help you step by step." },
        { "overwhelmed", "Take a deep breath. We can handle one thing at a time. What’s on your mind first?" }
    };

    public static void Main()
    {
        DisplayAsciiArt();
        PlayVoiceGreeting();

        string userName = GetUserName();
        userMemory["name"] = userName;

        Console.WriteLine($"\n{GetRandomGreeting()}, {userName}! Ready to boost your cybersecurity and wellness?");
        Console.WriteLine("Just ask me anything or type 'bye' to exit.");

        StartChatbotInteraction();
    }

    private static void StartChatbotInteraction()
    {
        while (true)
        {
            DisplayUserPrompt();
            string input = Console.ReadLine().ToLower();
            conversationHistory.Add($"You: {input}");

            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Bot: Please say something!");
                continue;
            }

            if (input.Contains(ExitCommand))
            {
                Console.WriteLine($"\nBot: {GetRandomFarewell()}, {userMemory.GetValueOrDefault("name", "user")}");
                break;
            }

            string response = ProcessInput(input);
            DisplayChatbotResponse(response);
            conversationHistory.Add($"Bot: {response}");
        }

        Console.WriteLine($"\nBot: It was great chatting, {userMemory.GetValueOrDefault("name", "user")}. Stay safe!");
    }

    private static string ProcessInput(string input)
    {
        if (greetings.Any(input.Contains)) return $"{GetRandomGreeting()} to you too!";
        if (acknowledgement.Any(input.Contains) && currentTopic != null)
            return $"{GetRandomAcknowledgement()}. What else about {currentTopic} interests you?";

        foreach (var keyword in randomResponses.Keys)
        {
            if (input.Contains(keyword))
            {
                currentTopic = keyword;
                var random = new Random();
                var tip = randomResponses[keyword][random.Next(randomResponses[keyword].Count)];
                return $"{GetRandomPositiveAffirmation()} Here’s a tip about {keyword}: {tip} {GetRandomFollowUpQuestion()}";
            }
        }

        foreach (var sentiment in sentimentResponses.Keys)
        {
            if (input.Contains(sentiment))
                return $"{sentimentResponses[sentiment]} {GetRandomFollowUpQuestion()}";
        }

        if (input.Contains("interested in"))
        {
            var words = input.Split(' ');
            int index = Array.IndexOf(words, "in");
            if (index >= 0 && index + 1 < words.Length)
            {
                string topic = words[index + 1];
                userMemory["interest"] = topic;
                return $"{GetRandomAcknowledgement()} I’ll remember you're interested in {topic}.";
            }
        }

        if (input.Contains("you remember") && userMemory.ContainsKey("interest"))
            return $"Yes, you mentioned being interested in {userMemory["interest"]}. {GetRandomFollowUpQuestion()}";

        if (currentTopic != null && (input.Contains("more about") || input.Contains("explain further")))
        {
            var random = new Random();
            var tip = randomResponses[currentTopic][random.Next(randomResponses[currentTopic].Count)];
            return $"Sure! Here's more on {currentTopic}: {tip} {GetRandomFollowUpQuestion()}";
        }

        if (currentTopic != null)
        {
            if (input.Contains("yes") || input.Contains("that's right"))
                return $"{GetRandomAcknowledgement()} {GetRandomFollowUpQuestion()}";
            if (input.Contains("no") || input.Contains("not really"))
                return $"Okay. What’s your take on {currentTopic}?";

            return $"Still discussing {currentTopic}. Anything else you'd like to explore?";
        }

        if (input.Contains("huh") || input.Contains("what do you mean") || input.Contains("i'm confused"))
            return GetRandomConfusionResponse();

        return "That's an interesting point! Could you please rephrase it for me?";
    }

    // Utilities
    private static string GetRandomGreeting() => greetings[new Random().Next(greetings.Count)];
    private static string GetRandomFarewell() => farewells[new Random().Next(farewells.Count)];
    private static string GetRandomAcknowledgement() => acknowledgement[new Random().Next(acknowledgement.Count)];
    private static string GetRandomPositiveAffirmation() => positiveAffirmations[new Random().Next(positiveAffirmations.Count)];
    private static string GetRandomFollowUpQuestion() => followUpQuestions[new Random().Next(followUpQuestions.Count)];
    private static string GetRandomConfusionResponse() => confusionResponses[new Random().Next(confusionResponses.Count)];

    private static void DisplayUserPrompt() => Console.Write("\nYou: ");
    private static void DisplayChatbotResponse(string response) => Console.WriteLine($"Bot: {response}");

    private static void PlayVoiceGreeting()
    {
        try
        {
            // Check if the file exists in the same directory as the executable
            if (File.Exists(VoiceGreetingPath))
            {
                using (SoundPlayer player = new SoundPlayer(VoiceGreetingPath))
                {
                    player.PlaySync(); // Play the sound and wait until it finishes
                }
            }
            else
            {
                Console.WriteLine($"Warning: Voice greeting file not found at '{VoiceGreetingPath}'.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error playing voice greeting: {ex.Message}");
        }
    }

    private static string GetUserName()
    {
        Console.Write("\nPlease enter your name: ");
        return Console.ReadLine();
    }

    private static void DisplayAsciiArt()
    {
        Console.WriteLine(@"
     _.-'''''-._
   .'           `.
  /   O     O     \
 |    \  ^^  /    |
 \     `.__.'     /
  `. _______ .'
    //_____\\
   (( ____ ))
    `------'
  Cyber Buddy v1.0
");
    }
}
